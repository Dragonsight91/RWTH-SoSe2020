#!/bin/bash

echo "$1" | sed 's/1/2/1'